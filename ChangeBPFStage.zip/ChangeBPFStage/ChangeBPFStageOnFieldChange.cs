﻿using System;
using Microsoft.Xrm.Sdk;
using System.Collections.Generic;

namespace ChangeBPFStage
{
    public class ChangeBPFStageOnFieldChange : IPlugin
    {
        public List<BPFStage> BPFStages { get; set; }
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            //IOrganizationService crmService = serviceFactory.CreateOrganizationService(context.UserId);
            IOrganizationService crmService = serviceFactory.CreateOrganizationService(null);
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                if (context.MessageName.ToLower().Equals("update") && context.PrimaryEntityName.ToLower().Equals("new_testentity"))
                {
                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                    {
                        //--- Create collection of BPF stages
                        BPFStages = new List<BPFStage>();
                        LoadBPFStagesList();

                        Entity entity = (Entity)context.InputParameters["Target"];
                        if (entity.Contains("new_stagename") && entity["new_stagename"] != null)
                        {
                            int stageValue = ((OptionSetValue)entity["new_stagename"]).Value;
                            MoveBPFStage(context, stageValue, entity, crmService, trace);
                        }
                    }
                }
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw ex;
            }
        }

        public void MoveBPFStage(IPluginExecutionContext context, int stageValue, Entity entity, IOrganizationService crmService, ITracingService trace)
        {
            Guid selectedStageId = Guid.Empty;
            int stageIndex = BPFStages.FindIndex(x => x.StageOrder == stageValue);
            selectedStageId = BPFStages[stageIndex].StageId;
            string traversedPath = GetExistingTraversedPath(entity, context);

            entity["stageid"] = selectedStageId;
            if (traversedPath != string.Empty)
            {
                var areMovingStageBack = AreMovingToBackStage(traversedPath, BPFStages[stageIndex]);
                trace.Trace("areMovingStageBack = " + areMovingStageBack);

                if(areMovingStageBack == true)
                {
                    //--Do not update traverse path in this case
                    //entity["traversedpath"] = selectedStageId;
                }
                else
                {
                    ValidateStagesOrder(traversedPath, selectedStageId, trace);
                    entity["traversedpath"] = traversedPath + "," + selectedStageId;
                }
            }
            else
            {
                entity["traversedpath"] = selectedStageId;
            }
        }

        public string GetExistingTraversedPath(Entity entity, IPluginExecutionContext context)
        {
            string traversedPath = string.Empty;
            if (entity.Contains("traversedpath") && entity["traversedpath"] != null)
            {
                traversedPath = entity["traversedpath"].ToString();
            }
            else
            {
                if (context.PreEntityImages.Contains("PreImage") && context.PreEntityImages["PreImage"] != null)
                {
                    Entity preImage = context.PreEntityImages["PreImage"];
                    if (preImage.Contains("traversedpath") && preImage["traversedpath"] != null)
                    {
                        traversedPath = preImage["traversedpath"].ToString();
                    }
                }
            }
            return traversedPath;
        }

        public void ValidateStagesOrder(string traversedPath, Guid selectedStageId, ITracingService trace)
        {
            trace.Trace("traversedPath = " + traversedPath.ToString());

            string currentSelectedStageId = string.Empty;
            string[] traverseStages = traversedPath.Split(new char[] { ',' });
            if (traverseStages.Length > 0)
            {
                currentSelectedStageId = traverseStages[traverseStages.Length - 1];
            }
            
            if (currentSelectedStageId != string.Empty)
            {
                BPFStage bpfStage_PreviousSelectedStage = BPFStages.Find(x => x.StageId == new Guid(currentSelectedStageId));
                BPFStage bpfStage_NextStage = BPFStages.Find(x => x.StageId == selectedStageId);

                if (bpfStage_PreviousSelectedStage != null && bpfStage_NextStage != null &&
                    bpfStage_PreviousSelectedStage.StageOrder + 1 != bpfStage_NextStage.StageOrder
                    )
                {
                    throw new InvalidPluginExecutionException("BPF stage can move to next adjacent stage only. To skip a stage between two stages is not allowed." + Environment.NewLine);
                }
            }
        }

        public bool AreMovingToBackStage(string traversedPath, BPFStage newSelectedStage)
        {
            bool areMovingStageBack = false;
            string lastStageIdInTraversedPath = string.Empty;
            string[] traverseStages = traversedPath.Split(new char[] { ',' });
            BPFStage lastStageInTraversedPath = null;

            if (traverseStages.Length > 0)
            {
                lastStageIdInTraversedPath = traverseStages[traverseStages.Length - 1];
                lastStageInTraversedPath = BPFStages.Find(x => x.StageId == new Guid(lastStageIdInTraversedPath));
            }

            if(newSelectedStage.StageOrder < lastStageInTraversedPath.StageOrder)
            {
                areMovingStageBack = true;
            }

            return areMovingStageBack;
        }

        public void LoadBPFStagesList()
        {
            BPFStage bpfStage = GetBPFStageObject("fc02e0d3-2aeb-427d-b0f7-a04e60c8e93d", "Capture Details", 1);
            BPFStages.Add(bpfStage);

            bpfStage = GetBPFStageObject("c8cb65c6-b38a-4032-8756-bff2e01b1a8c", "Develop", 2);
            BPFStages.Add(bpfStage);

            bpfStage = GetBPFStageObject("7b3aca67-1634-4d92-bddc-174c878ef4bc", "Propose", 3);
            BPFStages.Add(bpfStage);

            bpfStage = GetBPFStageObject("d2f32f0f-773a-41ab-b307-a295e61120c7", "Close", 4);
            BPFStages.Add(bpfStage);
        }

        public BPFStage GetBPFStageObject(string stageId, string stageName, int stageOrder)
        {
            BPFStage bpfStage = new BPFStage();
            bpfStage.StageId = new Guid(stageId);
            bpfStage.StageName = stageName;
            bpfStage.StageOrder = stageOrder;
            return bpfStage;
        }
    }

    public enum StageName
    {
        CaptureDetails = 1,
        Develop = 2,
        Propose = 3,
        Close = 4
    }

    public class BPFStage
    {
        public Guid StageId { get; set; }
        public int StageOrder { get; set; }
        public string StageName { get; set; }
        public bool IsSelectedStage { get; set; }
        public string TraversedPath { get; set; }
        public BPFStage()
        {
            IsSelectedStage = false;
        }
    }
}
